setwd("C:\\Users\\ASUS\\Desktop\\IT24102397\\Lab 8")

data<-read.table("Exercise - LaptopsWeights.txt", header=TRUE)
fix(data)
attach(data)

# Q1
popmn <- mean(Weight.kg.)
popvar<-var(Weight.kg.)
popDev <- sqrt(popvar)

#Q2
samples<-c()
n<-c()

for(i in 25){
  s<-sample(Weight.kg.,6,replace=TRUE)
  samples<-cbind(samples,s)
  n<-c(n,paste('s',i))
}
colnames(samples)=n

s.mean<-apply(samples,2,mean)
s.vars<-apply(samples,2,var)
s.sd <- sqrt(s.vars)

#Q3
samplemean <- mean(s.mean)
samplevar<-var(s.mean)
samplesd <- sqrt(samplevar)


# population mean and sample mean are equal
#population standard devation and sample standard deviation are different

#both are not equal. Population standard deviation is greater than sample standard deviation
